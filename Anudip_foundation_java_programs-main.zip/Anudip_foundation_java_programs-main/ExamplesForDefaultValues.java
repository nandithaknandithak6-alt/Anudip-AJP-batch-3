public class ExamplesForDefaultValues {
    public static void main(String[] args) {
		
       ExamplesForDefaultValues e = new ExamplesForDefaultValues();
       int a;
       int b;
       
       System.out.println(a);
       System.out.println(b);
       
	}

}
