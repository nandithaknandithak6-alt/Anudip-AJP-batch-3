public class ExampleForDoWhile {

	public static void main(String[] args) {
		
		int x = 1;
		
		do {
			System.out.println(x);
			x++;
		}
		while(x<=5);

	}

}
